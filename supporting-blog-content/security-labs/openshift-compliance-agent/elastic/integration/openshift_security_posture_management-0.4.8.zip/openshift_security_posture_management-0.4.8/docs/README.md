# OpenShift Security Posture Management

The OpenShift Security Posture Management (OSPM) integration allows you to identify configuration risks across the components that make up your OpenShift cluster. It does this by evaluating your OpenShift clusters against industry security benchmarks and compliance profiles (such as CIS, NIST SP 800-53, FedRAMP, Australian Essential Eight, and custom tailored profiles) enabled via the OpenShift Compliance Operator, generating findings with step-by-step instructions for remediating potential security risks.

## compliance remediations

Provides automated remediation actions for rules identified in the compliance check results that do not have a manual status.

An example event for `compliance_remediations` looks as following:

```json
{
  "orchestrator": {
    "namespace": "openshift-compliance",
    "type": "OpenShift",
    "resource": {
      "name": "ocp4-cis-api-server-audit-log-maxsize",
      "type": "ComplianceRemediation"
    }
  },
  "openshift_security_posture_management": {
    "compliance_remediations": {
      "metadata": {
        "generation": 1,
        "uid": "9f64957f-8cb8-4766-b85a-6b1ab7d59e82",
        "resource_version": "13401424",
        "owner_references": [
          {
            "uid": "8936a60b-40a4-49d3-817d-2a8c051d08d7",
            "controller": true,
            "apiVersion": "compliance.openshift.io/v1alpha1",
            "kind": "ComplianceCheckResult",
            "name": "ocp4-cis-api-server-audit-log-maxsize",
            "blockOwnerDeletion": true
          }
        ],
        "labels": {
          "compliance.openshift.io/scan-name": "ocp4-cis",
          "compliance.openshift.io/suite": "cis-compliance-scan"
        }
      },
      "api_version": "compliance.openshift.io/v1alpha1",
      "kind": "ComplianceRemediation",
      "spec": {
        "current": {
          "metadata": {
            "name": "cluster"
          },
          "apiVersion": "config.openshift.io/v1",
          "kind": "APIServer",
          "spec": {
            "maximumFileSizeMegabytes": 100
          }
        },
        "type": "Configuration",
        "apply": false
      },
      "status": {
        "application_state": "NotApplied"
      }
    }
  },
  "@timestamp": "2026-01-05T04:19:12.000Z",
  "ecs": {
    "version": "9.3.0"
  },
  "event": {
    "original": "{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"kind\":\"ComplianceRemediation\",\"metadata\":{\"creationTimestamp\":\"2026-01-05T04:19:12Z\",\"generation\":1,\"labels\":{\"compliance.openshift.io/scan-name\":\"ocp4-cis\",\"compliance.openshift.io/suite\":\"cis-compliance-scan\"},\"managedFields\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"fieldsType\":\"FieldsV1\",\"fieldsV1\":{\"f:status\":{}},\"manager\":\"compliance-operator\",\"operation\":\"Update\",\"time\":\"2026-01-05T04:19:13Z\"},{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"fieldsType\":\"FieldsV1\",\"fieldsV1\":{\"f:status\":{\"f:applicationState\":{}}},\"manager\":\"compliance-operator\",\"operation\":\"Update\",\"subresource\":\"status\",\"time\":\"2026-08-26T04:29:03Z\"}],\"name\":\"ocp4-cis-api-server-audit-log-maxsize\",\"namespace\":\"openshift-compliance\",\"ownerReferences\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"blockOwnerDeletion\":true,\"controller\":true,\"kind\":\"ComplianceCheckResult\",\"name\":\"ocp4-cis-api-server-audit-log-maxsize\",\"uid\":\"8936a60b-40a4-49d3-817d-2a8c051d08d7\"}],\"resourceVersion\":\"13401424\",\"uid\":\"9f64957f-8cb8-4766-b85a-6b1ab7d59e82\"},\"spec\":{\"apply\":false,\"current\":{\"object\":{\"apiVersion\":\"config.openshift.io/v1\",\"kind\":\"APIServer\",\"metadata\":{\"name\":\"cluster\"},\"spec\":{\"maximumFileSizeMegabytes\":100}}},\"outdated\":{},\"type\":\"Configuration\"},\"status\":{\"applicationState\":\"NotApplied\"}}",
    "category": [
      "configuration"
    ],
    "type": [
      "info"
    ],
    "kind": "state"
  }
}
```

<details>
<summary>Exported fields</summary>

| Field | Type |
|-------|------|
| @timestamp | date |
| ecs.version | keyword |
| event.category | keyword |
| event.kind | keyword |
| event.original | keyword |
| event.type | keyword |
| openshift_security_posture_management.compliance_remediations.api_version | keyword |
| openshift_security_posture_management.compliance_remediations.kind | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.generation | long |
| openshift_security_posture_management.compliance_remediations.metadata.labels.compliance.openshift.io/scan-name | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.labels.compliance.openshift.io/suite | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.apiVersion | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.blockOwnerDeletion | boolean |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.controller | boolean |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.kind | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.name | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.owner_references.uid | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.resource_version | keyword |
| openshift_security_posture_management.compliance_remediations.metadata.uid | keyword |
| openshift_security_posture_management.compliance_remediations.spec.apply | boolean |
| openshift_security_posture_management.compliance_remediations.spec.current.apiVersion | keyword |
| openshift_security_posture_management.compliance_remediations.spec.current.kind | keyword |
| openshift_security_posture_management.compliance_remediations.spec.current.metadata.name | keyword |
| openshift_security_posture_management.compliance_remediations.spec.current.spec.encryption.type | keyword |
| openshift_security_posture_management.compliance_remediations.spec.current.spec.maximumFileSizeMegabytes | long |
| openshift_security_posture_management.compliance_remediations.spec.type | keyword |
| openshift_security_posture_management.compliance_remediations.status.application_state | keyword |
| orchestrator.namespace | keyword |
| orchestrator.resource.name | keyword |
| orchestrator.resource.type | keyword |
| orchestrator.type | keyword |

</details>

## compliance scans

Provides compliance scans along with their current status.

An example event for `compliance_scans` looks as following:

```json
{
  "openshift_security_posture_management": {
    "compliance_scans": {
      "metadata": {
        "generation": 1,
        "resource_version": "13401720"
      },
      "kind": "ComplianceScan",
      "scan": {
        "show_not_applicable": false,
        "profile": "xccdf_org.ssgproject.content_profile_cis",
        "name": "ocp4-cis",
        "strict_node_scan": true,
        "id": "d383eaed-3530-404a-a129-aa2aad124ee9",
        "type": "Platform",
        "content_image": "quay.io/compliance-operator/compliance-operator-content:latest",
        "content": "ssg-ocp4-ds.xml"
      },
      "namespace": "openshift-compliance",
      "api_version": "compliance.openshift.io/v1alpha1",
      "status": {
        "phase": "DONE",
        "result": "NON-COMPLIANT",
        "results_storage": {
          "name": "ocp4-cis",
          "namespace": "openshift-compliance"
        },
        "warnings": "could not fetch /apis/flowcontrol.apiserver.k8s.io/v1alpha1/flowschemas/catch-all: the server could not find the requested resource\ncould not fetch /apis/flowcontrol.apiserver.k8s.io/v1beta1/flowschemas/catch-all: the server could not find the requested resource\ncould not fetch /apis/flowcontrol.apiserver.k8s.io/v1beta2/flowschemas/catch-all: the server could not find the requested resource\ncould not fetch /apis/logging.openshift.io/v1/namespaces/openshift-logging/clusterlogforwarders/instance: the server could not find the requested resource\ncould not fetch /apis/apps/v1/namespaces/openshift-sdn/daemonsets/sdn: daemonsets.apps \"sdn\" not found\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch \"/api/v1/nodes/NODE_NAME/proxy/configz\": the server could not find the requested resource\ncould not fetch /apis/hypershift.openshift.io/v1alpha1/namespaces/clusters/hostedclusters/None: the server could not find the requested resource",
        "current_index": 1
      }
    }
  },
  "@timestamp": "2026-01-05T04:18:02.000Z",
  "ecs": {
    "version": "9.3.0"
  },
  "event": {
    "original": "{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"kind\":\"ComplianceScan\",\"metadata\":{\"creationTimestamp\":\"2026-01-05T04:18:02Z\",\"finalizers\":[\"scan.finalizers.compliance.openshift.io\"],\"generation\":1,\"labels\":{\"compliance.openshift.io/suite\":\"cis-compliance-scan\"},\"managedFields\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"fieldsType\":\"FieldsV1\",\"fieldsV1\":{\"f:status\":{\".\":{},\"f:currentIndex\":{},\"f:resultsStorage\":{\".\":{},\"f:name\":{},\"f:namespace\":{}},\"f:warnings\":{}}},\"manager\":\"compliance-operator\",\"operation\":\"Update\",\"time\":\"2026-08-26T04:27:18Z\"},{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"fieldsType\":\"FieldsV1\",\"fieldsV1\":{\"f:status\":{\"f:phase\":{},\"f:result\":{}}},\"manager\":\"compliance-operator\",\"operation\":\"Update\",\"subresource\":\"status\",\"time\":\"2026-08-26T04:29:25Z\"}],\"name\":\"ocp4-cis\",\"namespace\":\"openshift-compliance\",\"ownerReferences\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"blockOwnerDeletion\":true,\"controller\":true,\"kind\":\"ComplianceSuite\",\"name\":\"cis-compliance-scan\",\"uid\":\"b28bf4b6-64be-44e0-ae0f-a0594994a87a\"}],\"resourceVersion\":\"13401720\",\"uid\":\"d383eaed-3530-404a-a129-aa2aad124ee9\"},\"spec\":{\"content\":\"ssg-ocp4-ds.xml\",\"contentImage\":\"quay.io/compliance-operator/compliance-operator-content:latest\",\"profile\":\"xccdf_org.ssgproject.content_profile_cis\",\"rawResultStorage\":{\"nodeSelector\":{\"node-role.kubernetes.io/master\":\"\"},\"pvAccessModes\":[\"ReadWriteOnce\"],\"rotation\":3,\"size\":\"1Gi\",\"tolerations\":[{\"effect\":\"NoSchedule\",\"key\":\"node-role.kubernetes.io/master\",\"operator\":\"Exists\"},{\"effect\":\"NoExecute\",\"key\":\"node.kubernetes.io/not-ready\",\"operator\":\"Exists\",\"tolerationSeconds\":300},{\"effect\":\"NoExecute\",\"key\":\"node.kubernetes.io/unreachable\",\"operator\":\"Exists\",\"tolerationSeconds\":300},{\"effect\":\"NoSchedule\",\"key\":\"node.kubernetes.io/memory-pressure\",\"operator\":\"Exists\"}]},\"scanTolerations\":[{\"operator\":\"Exists\"}],\"scanType\":\"Platform\",\"showNotApplicable\":false,\"strictNodeScan\":true},\"status\":{\"currentIndex\":1,\"phase\":\"DONE\",\"result\":\"NON-COMPLIANT\",\"resultsStorage\":{\"name\":\"ocp4-cis\",\"namespace\":\"openshift-compliance\"},\"warnings\":\"could not fetch /apis/flowcontrol.apiserver.k8s.io/v1alpha1/flowschemas/catch-all: the server could not find the requested resource\\ncould not fetch /apis/flowcontrol.apiserver.k8s.io/v1beta1/flowschemas/catch-all: the server could not find the requested resource\\ncould not fetch /apis/flowcontrol.apiserver.k8s.io/v1beta2/flowschemas/catch-all: the server could not find the requested resource\\ncould not fetch /apis/logging.openshift.io/v1/namespaces/openshift-logging/clusterlogforwarders/instance: the server could not find the requested resource\\ncould not fetch /apis/apps/v1/namespaces/openshift-sdn/daemonsets/sdn: daemonsets.apps \\\"sdn\\\" not found\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch \\\"/api/v1/nodes/NODE_NAME/proxy/configz\\\": the server could not find the requested resource\\ncould not fetch /apis/hypershift.openshift.io/v1alpha1/namespaces/clusters/hostedclusters/None: the server could not find the requested resource\"}}",
    "category": [
      "configuration"
    ],
    "type": [
      "info"
    ],
    "kind": "state",
    "outcome": "failure"
  },
  "message": "Compliance scan ocp4-cis result: NON-COMPLIANT"
}
```

<details>
<summary>Exported fields</summary>

| Field | Type |
|-------|------|
| @timestamp | date |
| ecs.version | keyword |
| event.category | keyword |
| event.kind | keyword |
| event.original | keyword |
| event.outcome | keyword |
| event.type | keyword |
| message | match_only_text |
| openshift_security_posture_management.compliance_scans.api_version | keyword |
| openshift_security_posture_management.compliance_scans.kind | keyword |
| openshift_security_posture_management.compliance_scans.metadata.generation | long |
| openshift_security_posture_management.compliance_scans.metadata.resource_version | keyword |
| openshift_security_posture_management.compliance_scans.namespace | keyword |
| openshift_security_posture_management.compliance_scans.scan.content | keyword |
| openshift_security_posture_management.compliance_scans.scan.content_image | keyword |
| openshift_security_posture_management.compliance_scans.scan.id | keyword |
| openshift_security_posture_management.compliance_scans.scan.name | keyword |
| openshift_security_posture_management.compliance_scans.scan.profile | keyword |
| openshift_security_posture_management.compliance_scans.scan.show_not_applicable | keyword |
| openshift_security_posture_management.compliance_scans.scan.strict_node_scan | keyword |
| openshift_security_posture_management.compliance_scans.scan.type | keyword |
| openshift_security_posture_management.compliance_scans.status.current_index | long |
| openshift_security_posture_management.compliance_scans.status.phase | keyword |
| openshift_security_posture_management.compliance_scans.status.result | keyword |
| openshift_security_posture_management.compliance_scans.status.results_storage.name | keyword |
| openshift_security_posture_management.compliance_scans.status.results_storage.namespace | keyword |
| openshift_security_posture_management.compliance_scans.status.warnings | keyword |

</details>

## compliance check results

Provides compliance results based on the checks performed during the configured scan.

An example event for `compliance_check_results` looks as following:

```json
{
  "orchestrator": {
    "namespace": "openshift-compliance",
    "resource": {
      "name": "ocp4-cis-accounts-restrict-service-account-tokens",
      "type": "ComplianceCheckResult"
    }
  },
  "@timestamp": "2026-01-05T04:19:15.000Z",
  "ecs": {
    "version": "9.3.0"
  },
  "rule": {
    "name": "accounts-restrict-service-account-tokens",
    "description": "Restrict Automounting of Service Account Tokens\nMounting service account tokens inside pods can provide an avenue\nfor privilege escalation attacks where an attacker is able to\ncompromise a single pod in the cluster.",
    "id": "xccdf_org.ssgproject.content_rule_accounts_restrict_service_account_tokens"
  },
  "openshift_security_posture_management": {
    "compliance_check_results": {
      "severity": "medium",
      "metadata": {
        "name": "ocp4-cis-accounts-restrict-service-account-tokens",
        "namespace": "openshift-compliance",
        "uid": "35c69f89-160b-40c6-9732-9e69d7559a5e",
        "resource_version": "1601948"
      },
      "kind": "ComplianceCheckResult",
      "owner_references": [
        {
          "uid": "d383eaed-3530-404a-a129-aa2aad124ee9",
          "controller": true,
          "apiVersion": "compliance.openshift.io/v1alpha1",
          "kind": "ComplianceScan",
          "name": "ocp4-cis",
          "blockOwnerDeletion": true
        }
      ],
      "rule": {
        "remediation": "For each pod in the cluster, review the pod specification and\nensure that pods that do not need to explicitly communicate with\nthe API server have automountServiceAccountToken\nconfigured to false."
      },
      "api_version": "compliance.openshift.io/v1alpha1",
      "status": "MANUAL",
      "labels": {
        "suite": "cis-compliance-scan",
        "scan_name": "ocp4-cis",
        "check_status": "MANUAL",
        "check_severity": "medium"
      }
    }
  },
  "event": {
    "action": "manual",
    "original": "{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"description\":\"Restrict Automounting of Service Account Tokens\\nMounting service account tokens inside pods can provide an avenue\\nfor privilege escalation attacks where an attacker is able to\\ncompromise a single pod in the cluster.\",\"id\":\"xccdf_org.ssgproject.content_rule_accounts_restrict_service_account_tokens\",\"instructions\":\"For each pod in the cluster, review the pod specification and\\nensure that pods that do not need to explicitly communicate with\\nthe API server have automountServiceAccountToken\\nconfigured to false.\",\"kind\":\"ComplianceCheckResult\",\"metadata\":{\"annotations\":{\"compliance.openshift.io/rule\":\"accounts-restrict-service-account-tokens\"},\"creationTimestamp\":\"2026-01-05T04:19:15Z\",\"generation\":1,\"labels\":{\"compliance.openshift.io/check-severity\":\"medium\",\"compliance.openshift.io/check-status\":\"MANUAL\",\"compliance.openshift.io/scan-name\":\"ocp4-cis\",\"compliance.openshift.io/suite\":\"cis-compliance-scan\"},\"managedFields\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"fieldsType\":\"FieldsV1\",\"fieldsV1\":{\"f:description\":{},\"f:id\":{},\"f:instructions\":{},\"f:metadata\":{\"f:annotations\":{\".\":{},\"f:compliance.openshift.io/rule\":{}},\"f:labels\":{\".\":{},\"f:compliance.openshift.io/check-severity\":{},\"f:compliance.openshift.io/check-status\":{},\"f:compliance.openshift.io/scan-name\":{},\"f:compliance.openshift.io/suite\":{}},\"f:ownerReferences\":{\".\":{},\"k:{\\\"uid\\\":\\\"d383eaed-3530-404a-a129-aa2aad124ee9\\\"}\":{}}},\"f:severity\":{},\"f:status\":{}},\"manager\":\"compliance-operator\",\"operation\":\"Update\",\"time\":\"2026-01-05T04:19:15Z\"}],\"name\":\"ocp4-cis-accounts-restrict-service-account-tokens\",\"namespace\":\"openshift-compliance\",\"ownerReferences\":[{\"apiVersion\":\"compliance.openshift.io/v1alpha1\",\"blockOwnerDeletion\":true,\"controller\":true,\"kind\":\"ComplianceScan\",\"name\":\"ocp4-cis\",\"uid\":\"d383eaed-3530-404a-a129-aa2aad124ee9\"}],\"resourceVersion\":\"1601948\",\"uid\":\"35c69f89-160b-40c6-9732-9e69d7559a5e\"},\"severity\":\"medium\",\"status\":\"MANUAL\"}",
    "category": [
      "configuration"
    ],
    "type": [
      "info"
    ],
    "kind": "state"
  },
  "message": "Restrict Automounting of Service Account Tokens\nMounting service account tokens inside pods can provide an avenue\nfor privilege escalation attacks where an attacker is able to\ncompromise a single pod in the cluster."
}
```

<details>
<summary>Exported fields</summary>

| Field | Type |
|-------|------|
| @timestamp | date |
| ecs.version | keyword |
| event.action | keyword |
| event.category | keyword |
| event.kind | keyword |
| event.original | keyword |
| event.type | keyword |
| message | match_only_text |
| openshift_security_posture_management.compliance_check_results.api_version | keyword |
| openshift_security_posture_management.compliance_check_results.kind | keyword |
| openshift_security_posture_management.compliance_check_results.labels.check_severity | keyword |
| openshift_security_posture_management.compliance_check_results.labels.check_status | keyword |
| openshift_security_posture_management.compliance_check_results.labels.scan_name | keyword |
| openshift_security_posture_management.compliance_check_results.labels.suite | keyword |
| openshift_security_posture_management.compliance_check_results.metadata.name | keyword |
| openshift_security_posture_management.compliance_check_results.metadata.namespace | keyword |
| openshift_security_posture_management.compliance_check_results.metadata.resource_version | keyword |
| openshift_security_posture_management.compliance_check_results.metadata.uid | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.apiVersion | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.blockOwnerDeletion | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.controller | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.kind | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.name | keyword |
| openshift_security_posture_management.compliance_check_results.owner_references.uid | keyword |
| openshift_security_posture_management.compliance_check_results.rule.remediation | keyword |
| openshift_security_posture_management.compliance_check_results.severity | keyword |
| openshift_security_posture_management.compliance_check_results.status | keyword |
| orchestrator.namespace | keyword |
| orchestrator.resource.name | keyword |
| orchestrator.resource.type | keyword |
| rule.description | keyword |
| rule.id | keyword |
| rule.name | keyword |

</details>

## Dashboards and transforms

The package installs three dashboards (**[OpenShift Compliance] Posture Overview**, **[OpenShift Compliance] Overall Results** and **[OpenShift Compliance] Auto Remediations**). They query the `ospm-compliance_check_results-latest`, `ospm-compliance_scans-latest` and `ospm-compliance_remediations-latest` indices, which are maintained by three continuous `latest` transforms installed with the package. Each transform keeps the most recent document per cluster and resource (`orchestrator.cluster.name` plus the resource uid or scan name).

Every document must carry `orchestrator.cluster.name` for the transforms to group correctly. The `Processors` variable of each data stream defaults to an `add_fields` processor that sets it from the `CLUSTER_NAME` environment variable, so set `CLUSTER_NAME` on the Elastic Agent deployment (for example `CLUSTER_NAME=ocp-dev`). If the variable is missing, Elastic Agent cannot resolve it and does not start the input.

The package also installs two data views: `ospm-latest-results` (`ospm-compliance_*-latest`, the transformed indices used by the dashboards) and `ospm-raw-results` (`logs-openshift_security_posture_management.compliance*`, the raw data streams).

The transforms run with the privileges of the user who installs the package. That user needs `manage_transform`, read access to `logs-openshift_security_posture_management.*` and permission to create the `ospm-*` indices.

Annotations from the compliance resources are stored under `...compliance_scans.metadata.annotations`, `...compliance_remediations.metadata.annotations` and `...compliance_check_results.annotations`, and all check result labels under `...compliance_check_results.labels`. Dots and slashes in keys are replaced with underscores.
